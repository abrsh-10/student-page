export class Topic {
  topicId!: string;
  topicTitle!: string;
  topicDescription!: string;
  courseId!: string;
}
