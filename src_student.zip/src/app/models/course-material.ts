export class CourseMaterial {
  courseMaterialName?: string;
  courseMaterialSize?: number;
  courseMaterialDescription?: string;
}
