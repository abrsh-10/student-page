export class Assignments {
}
