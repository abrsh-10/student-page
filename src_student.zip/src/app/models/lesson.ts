export class Lesson {
  lessonId!: string;
  lessonTitle!: string;
  lessonVideoId!: string;
  lessonDescription!: string;
  topicId!: string;
}
