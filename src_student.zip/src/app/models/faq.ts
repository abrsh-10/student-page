export class Faq {
  id!: string;
  question!: string;
  answer!: string;
  expanded?: boolean;
}
